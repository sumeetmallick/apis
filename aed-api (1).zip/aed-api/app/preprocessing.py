import os
import re
import string
import requests
import unidecode
import contractions
import preprocessor as p
import pandas as pd
import tensorflow as tf

from emoji import demojize
from bs4 import BeautifulSoup
from tqdm import tqdm
from autocorrect import Speller

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, precision_recall_curve, confusion_matrix, roc_curve, precision_score, recall_score, f1_score , log_loss, roc_auc_score
from transformers import RobertaTokenizerFast, TFRobertaForSequenceClassification, TFTrainer, TFTrainingArguments, EvalPrediction

spell = Speller()

class PreprocessingPipeline():
  """
  A utility class which defines a flexible text processing pipeline.
  If steps are not passed in, all steps will be applied by default.
  """

  def __init__(self, **kwargs):
    # get steps
    p.set_options(p.OPT.MENTION, p.OPT.URL, p.OPT.RESERVED, p.OPT.SMILEY)
    self.accented_characters = kwargs.get('accented_characters', True)
    self.lowercase = kwargs.get('lowercase', True)
    self.mentions_and_urls = kwargs.get('mentions_and_urls', True)
    self.emojis = kwargs.get('emojis', True)
    self.hashtags = kwargs.get('hastags', True)
    self.fix_and_expand_contractions = kwargs.get('fix_and_expand_contractions', True)
    self.slang = kwargs.get('slang', True)
    self.punctuation = kwargs.get('punctuation', True)
    self.spellcheck = kwargs.get('spellcheck', True)
    self.multiple_periods = kwargs.get('multiple_periods', True)
    self.multiple_whitespaces = kwargs.get('multiple_whitespaces', True)
    self.available_steps = ['accented_characters',
                            'lowercase',
                            'mentions_and_urls',
                            'emojis',
                            'hashtags',
                            'fix_and_expand_contractions',
                            'slang',
                            'punctuation',
                            'spellcheck',
                            'multiple_periods',
                            'multiple_whitespaces']

    # create pipeline queing the requested steps
    self.pipeline_steps = [step for step in self.available_steps if getattr(self, step) == True]
    print('The following transforms will be applied:\n {}'.format(self.pipeline_steps))

    # get slang dictionary
    if self.slang == True:
      print("\nReadying slang dictionary")
    self.abv_dict = self.parse_noslang(URL='https://www.noslang.com/dictionary/')
    print('Done!')


  # utility function to get slang dictionary if 'slang' transformation is requested
  def parse_noslang(self, URL):
    cached_path = os.path.join(os.getcwd(), 'slang_dict')
    if os.path.isfile(cached_path):
      print(f'Loading cached dictionary from: {cached_path}')
      abv_dict = dict()
      with open(cached_path, 'r') as f:
        for line in f.readlines():
          line = line.rstrip()
          try:
            abv, word = line.split('--', 1)
          except:
            continue
          if abv is not None and word is not None:
            abv_dict[abv] = word
      return abv_dict
    else:
      print(f'Parsing from: {URL}')
      abreviations = []
      words = []
      for letter in tqdm(string.ascii_lowercase + '1'):
        r = requests.get(URL+letter)
        page_body = r.text
        soup = BeautifulSoup(page_body, 'html.parser')
        abreviations_tags = soup.find_all('dt')
        for abv in abreviations_tags:
          txt = abv.get_text()[:-2]
          abreviations.append(txt)
        words_tags = soup.find_all('dd')
        for tag in words_tags:
          if tag is not None:
            text = tag.get_text()
            words.append(text)
      abv_dict = dict(zip(abreviations, words))
      with open(os.path.join(os.getcwd(), 'slang_dict'), 'w') as f:
        for k, v in abv_dict.items():
          if k is not None and v is not None:
            f.write(k + '--' + v + '\n')
          else:
            print(k, v)
      return abv_dict

  # utility to add some words to the vocabulary
  def add_vocab(self, list_of_tuples_of_vocab):
    for slang, meaning in list_of_tuples_of_vocab:
      self.abv_dict[slang] = meaning

  def add_transform(self, transform_func, transform_name, transform_position):
    assert type(transform_func('just some dummy text')) == str
    self.pipeline_steps.insert(self.pipeline_steps.index(transform_position), transform_name)
    transform_func.__name__ = f'process_{transform_name}'
    setattr(self, transform_func.__name__, transform_func)
    print(f'Added a new transform: {transform_name}\n')
    print(f'The following transforms will be applied:\n {self.pipeline_steps}')

  # utility to catch slangs in a passed word
  def catch_slang(self, word):
    try:
      self.abv_dict[word]
      return False
    except KeyError:
      return True

  # Remove accented characters
  def process_accented_characters(self, text):
    return unidecode.unidecode(text)

  # Correct typos
  def process_spellcheck(self, text):
    return spell(text)

  # Replace mentions with @user, and remove HTML and web URL artifacts
  def process_mentions_and_urls(self, text):
    return p.tokenize(text).replace('$MENTION$', '@user').replace('$URL$', ' ').replace('$SMILEY$', ' ').replace('$RESERVED$', ' ')

  # Replace emojis with their emotion
  def process_emojis(self, text):
    return demojize(text)

  # Correct typos
  def process_spellcheck(self, text):
    return spell(text)

  # Remove hashtags and normalize
  def process_hashtags(self, text):
    return text.replace('#', ' ')

  # Remove slangs
  def process_slang(self, text):
    text = ' '.join([x if self.catch_slang(x) else self.abv_dict[x] for x in text.lower().split(" ")])
    return text

  # Fix and expand contractions
  def process_fix_and_expand_contractions(self, text):
    text = re.sub("( n't)+", "n't", text)
    text = re.sub("( 'm)+", "'m", text)
    text = re.sub("( 'd)+", "d'", text)
    text = re.sub("( 'll)+", "'ll", text)
    text = re.sub("( 've)+", "'ve", text)
    text = re.sub("( 're)+", "'re", text)
    text = re.sub("( 's)+", "'s", text)
    return contractions.fix(text)

  # Remove punctuations except [@,']
  def process_punctuation(self, text):
    exclude = """.!"()*+,-/:;<=>?[\]^_`{|}~"""
    for punctuation in exclude:
      text = text.replace(punctuation, " ")
    return text

  # Clean up multiple periods
  def process_multiple_periods(self, text):
    return re.sub("(\ \.)+", " . ", text)

  def process_lowercase(self, text):
    return text.lower()

  # Clean up multiple whitespaces
  def process_multiple_whitespaces(self, text):
    return " ".join(text.split())

  # execute pipeline using requested steps
  def execute_pipeline(self, text):
    self.text = text
    for step in self.pipeline_steps:
      self.text = getattr(self, f'process_{step}')(self.text)
    return self.text

def get_pipeline():
    pipeline = PreprocessingPipeline(spellcheck = False, slang=True, punctuations=False)
    extra_vocab = [('bcos', 'because'),
               ('gunna', 'going to'),
               ('shoulda', 'should have'),
               ("tht's", "that is"),
               ('gotcha.', 'got it.'),
               ('im', 'i am')]
    pipeline.add_vocab(extra_vocab)
    return pipeline