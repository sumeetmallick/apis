import tensorflow as tf
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np
import os
from transformers import RobertaTokenizer, TFRobertaModel, TFRobertaForSequenceClassification,TFBertForSequenceClassification
import transformers
import json

from typing import Union, List, Tuple
from tqdm import tqdm
from transformers import RobertaTokenizerFast, TFRobertaForSequenceClassification, TFTrainer, TFTrainingArguments, EvalPrediction

import app.config as cfg

pd.set_option('display.max_colwidth', None)
pd.set_option("max_colwidth",None)
pd.set_option('display.max_rows', None)

config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.compat.v1.Session(config=config)


class ClassModel:
    def __init__(self):
        print("Welcome to Classification")
        strategy = tf.distribute.MirroredStrategy()
        with strategy.scope():
            self.tokenizer = RobertaTokenizer.from_pretrained('roberta-large')
            self.roberta_model = TFRobertaForSequenceClassification.from_pretrained('roberta-large',num_labels=2)
            self.roberta_model.load_weights(cfg.weights['classification_model'])

    def batch(self, iterable, n=1):
        """ Function for batching examples. """
        l = len(iterable)           # length of the iterator with values
        for ndx in range(0, l, n):  # get n iter values at a time.
            yield iterable[ndx:min(ndx + n, l)] # returning values continuously

    def predict(self, example: Union[str, List[str]], batch_size: int = 25, threshold=0.5) -> Tuple[np.array, np.array, np.array]:
        """ Returns predicted class for the input being passed to it.

        Runs the classification model, and predicts the label according to the threshold
        being passed to the function. Default threshold is 0.5.

        Args:
            example: List of strings, where each element is one input instance.
            batch_size: Integer number for splitting and batching large input instances. Default is 500.
            threshold: Float value, for specifying the minimum threshold for the positive class. Default is 0.5.

        Returns:
            List containing predicted labels.

        """
        logits = []
        probs = []
        labels = []
        print('Using threshold-->', threshold)
        for pred_batch in tqdm(self.batch(example, batch_size), total = int(len(example)/batch_size + 0.5)): # Create progress bar and access the batch of inputs sequentially
            tokenized_batch = self.tokenizer(pred_batch,max_length=100, padding='max_length', add_special_tokens=True, truncation=True, return_tensors='tf')
            logits_batch = self.roberta_model(tokenized_batch) # Each tokenized sentence batch fed to the model for prediction
            logits.append(logits_batch[0].numpy()) # # Gets the tensor of predicted values
            probs.append(tf.nn.softmax(logits_batch[0], axis=-1)) # applying softmax to outputs from model

        logits = np.vstack(logits)
        probs = np.vstack(probs)
        y_pred = probs[:,1]
        print("Predicted probability for AE: ", y_pred)
        labels = (y_pred > threshold).astype(int)

        return labels.tolist()

    def predict_csv(self, threshold):
        """ Predicts AE Class (0 or 1) for a specific threshold value for all examples in the file.

        This function will load a trained Classification model, and pass all the rows of the 'processedText'
        column of 'csvfile.csv', preprocessed in main.py, to the model. The threshold is the minimum probability
        that a prediction for the positive class needs to have, to call out the example as positive, or AE.The
        labels are returned to the main function.

        Args:
            threshold: A float value between 0 and 1. Default is 0.5.

        Returns:
            Tuple, containing the Labels predicted (as a List) and the corresponding original text passed by User
            (also as a List)

        """

        testfilepath = "/csvfile.csv"
        testdf = pd.read_csv(testfilepath,lineterminator="\n")

        # output = testdf.apply(lambda row: self.predict(row['processedText'], threshold=threshold), axis=1)
        output = self.predict(example = testdf.processedText.to_list(), threshold=threshold)

        return (
            output,
            testdf['text'],
        )


    def predict_text(self,text, threshold):
        """ Predicts AE Class (0 or 1) for a specific threshold value passed to it, for the text input passed.

        This function will load a trained Classification model, and pass the input 'text' preprocessed in main.py,
        to the model. The threshold is the minimum probability that a prediction for the positive class needs to
        have, to call out the example as positive, or AE. The label is returned to the main function.

        Args:
            threshold: A float value between 0 and 1. Default is 0.5.

        Returns:
            Tuple, containing the Labels predicted (as a List) and the corresponding original text passed by User
            (also as a List)

        """

        label = self.predict(example = [text], threshold=threshold)

        return (
            label,
            text
        )

def get_class_model():
    """ Returns the ClassModel object.

    The instantiated ClassModel object will be used in the main.py function to run the required functions for each end point.

    Returns:
        ClassModel object

    """
    model = ClassModel()
    return model
