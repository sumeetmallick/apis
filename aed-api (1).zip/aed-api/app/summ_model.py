import torch
import re
import logging
import string
import numpy as np
import pandas as pd
import nltk

from collections import defaultdict
from pathlib import Path
from operator import itemgetter
from typing import Union, List
from datasets import load_metric
from sklearn.model_selection import train_test_split
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

from rouge_score import rouge_scorer

import app.config as cfg

nltk.download('punkt')


class SummModel:
    def __init__(self):
        print("Welcome to Summarization")
        self.model_path = cfg.weights['summ_model']
        self.checkpoint = self.get_model_checkpoint_from_path(self.model_path)
        self.prefix = ('summarize: ' if self.checkpoint.startswith('t5') else '')
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, use_fast=True)
        self.model = self.offload_to_device(AutoModelForSeq2SeqLM.from_pretrained(self.model_path), target_device=self.device)
        self.model.eval()


    def offload_to_device(self, target_object, target_device):
        """Send target_object to GPU (if available), else simply return it."""

        if self.device.type != "cpu":
          return target_object.to(target_device)
        else:
          return target_object

    def batch(self, iterable, n=1):
        """ Function for batching examples. """
        l = len(iterable)
        for ndx in range(0, l, n):
            yield iterable[ndx:min(ndx + n, l)]



    def generate(self, examples, model):
        """ Generates the summaries from the trained model.

        Summarises the input text, to return the Adverse Reactions present in them. These may be paraphrased or extracted.
        If no reaction found, returns the phrase - 'No reaction'.

        Args:
            examples: List of input text to run inference on.
            model: The loaded Transformer model to generate summaries.

        Returns:
            List of generated summaries containing the adverse reactions in the input text.

        """
        inputs = [self.prefix + text for text in examples]
        generated_predictions = list()
        for example in tqdm(self.batch(inputs, 16)):
          inputs = self.tokenizer(example, max_length=300, truncation=True, return_tensors='pt', padding=True)
          summary_ids = model.generate(self.offload_to_device(inputs['input_ids'], target_device=self.device), max_length=40)
          generated_predictions.extend([self.tokenizer.decode(ids, skip_special_tokens=True, clean_up_tokenization_spaces=False) for ids in summary_ids])
        torch.cuda.empty_cache()
        return generated_predictions

    def predict_csv(self):
        """ Predicts the AE (Reaction) as a summary for all examples in the file.

        This function will load a trained Summarization model, and pass all the rows of the 'processedText'
        column of 'csvfile.csv', preprocessed in main.py, to the model. This model was trained to summarize
        the input text in terms of any adverse reaction. So, it can either extract or paraphrase the reaction
        (if present) and generate that as the output, or return 'No Reaction' when it cannot find a reaction.
        The labels are returned to the main function.

        Returns:
            List of generated summaries for each input text in the CSV file.

        """

        testfilepath = "/csvfile.csv"
        dataset = pd.read_csv(testfilepath)
        model_predictions = pd.DataFrame(dataset.processedText.to_list(), columns=['processedText'])

        generated_summaries = self.generate(dataset.processedText.to_list(), self.model)

        return (
            generated_summaries
        )


    def predict_text(self, text):
        """ Generates the summaries from the trained model.

        This function will load a trained Summarization model, and pass the input text to the model. This model was trained
        to summarize the input text in terms of any adverse reaction. So, it can either extract or paraphrase the reaction
        (if present) and generate that as the output, or return 'No Reaction' when it cannot find a reaction.
        The label is returned to the main function.
        Args:
            text: The input text (string) on which to generate summary.

        Returns:
           The generated summary for the input text.

        """
        text = [text]
        generated_summaries = self.generate(text, self.model)
        return (
            generated_summaries
        )


def get_summ_model():
    """ Returns the SummModel object.

    The instantiated SummModel object will be used in the main.py function to run the required functions for each end point.

    Returns:
        SummModel object

    """
    model = SummModel()
    return model
