import tensorflow as tf
import pandas as pd
import numpy as np
from transformers import RobertaTokenizerFast, TFRobertaModel, TFRobertaForTokenClassification
import transformers
from typing import List
from statistics import mode, StatisticsError
from tqdm import tqdm

import app.config as cfg

pd.set_option('display.max_colwidth', None)
pd.set_option("max_colwidth",None)
pd.set_option('display.max_rows', None)

config = tf.compat.v1.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.compat.v1.Session(config=config)


class SpanModel:
    def __init__(self):
        print("Welcome to NER")
        strategy = tf.distribute.MirroredStrategy()
        with strategy.scope():
            self.tokenizer = RobertaTokenizerFast.from_pretrained('roberta-large', add_prefix_space=True)
            self.model = TFRobertaForTokenClassification.from_pretrained(cfg.weights['ner_model'])

    def ids_to_labels(self, ids: List[int], lookup: dict) -> List[str]:
      """Convert class ids to respective labels."""
      return [lookup[id] for id in ids]

    def batch(self, iterable, n=1):
        """ Function for batching examples. """
        l = len(iterable)           # length of the iterator with values
        for ndx in range(0, l, n):  # get n iter values at a time.
            yield iterable[ndx:min(ndx + n, l)] # returning values continuously


    def align_labels(self, inputs, label):
      """Align the labels with the input after tokenization."""
      word_ids = inputs.word_ids()
      previous_word_idx = None
      label_ids = []
      for word_idx in word_ids:
        if word_idx is None:
          label_ids.append(-100)
        elif word_idx != previous_word_idx:
          label_ids.append(label[word_idx])
        else:
          label_ids.append(label[word_idx])
        previous_word_idx = word_idx
      return label_ids

    def collapse_tokens(self, example: str, max_length: int) -> List[List[int]]:
      idx = 1
      enc = [self.tokenizer.encode(x, add_special_tokens=False) for x in example.split()]
      collapsed_tokens = []
      for token in enc:
          tokenoutput = []
          for ids in token:
            tokenoutput.append(idx)
            idx += 1
          collapsed_tokens.append(tokenoutput)
      truncated_collapsed_tokens = []
      for token in collapsed_tokens:
        if max_length-1 not in token:
          truncated_collapsed_tokens.append(token)
        else:
          truncated_collapsed_tokens.append(token[:token.index(max_length-1)+1])
          break
      return truncated_collapsed_tokens


    def resolve_conflict_by_prob(self, index: List[int], logits: np.array) -> int:
      highest_probability = np.argmax([np.max(logits.numpy().squeeze()[idx]) for idx in index])
      return index[highest_probability]

    def resolve_conflict_by_freq(self, index: List[int], predicted_tags: List[str]):
      tag_freqs = [predicted_tags[idx] for idx in index]
      return mode(tag_freqs)

    def resolve_conflict(self,index: List[int], predicted_tags: List[str], logits: np.array):
      try:
        resolved_tag = self.resolve_conflict_by_freq(index, predicted_tags)
      except StatisticsError:
        resolved_tag = predicted_tags[self.resolve_conflict_by_prob(index, logits)]
      return resolved_tag

    def map_to_tags(self, collapsed_tokens: List[List[int]], predicted_tags: List[str], logits: np.array) -> List[str]:
      mapped_tags = []
      for i in collapsed_tokens:
        if len(i) > 1:
          resolved_tag = self.resolve_conflict(i, predicted_tags, logits)
          mapped_tags.append(resolved_tag)
        else:
          mapped_tags.append(predicted_tags[i[0]])
      return mapped_tags


    def simplify_tags(self, mapped_tags: List[str]) -> List[str]:
      simplified_tags = list()
      for tag in mapped_tags:
        if tag in ['B-REACTION', 'I-REACTION']:
          simplified_tags.append('REACTION')
        elif tag == 'B-DRUG':
          simplified_tags.append('DRUG')
        else:
          simplified_tags.append(tag)
      return simplified_tags



    def predict(self, examples: List, batch_size: int = 25):
        """ Predict the tags for each input word.

        The trained NER/Span model will be loaded and used to tag the input string as drug, reaction, or
        neither. These tags are simplified (broken down) and returned as a List.

        Args:
          example: String of input text to run inference on.

        Returns:
          List of simplified tags, wherein each element corresponds to a word in the input text.

        """

        max_length = 100
        output = []

        for pred_batch in tqdm(self.batch(examples, batch_size), total = int(len(examples)/batch_size + 0.5)):
            tokenized_batch = self.tokenizer(pred_batch, max_length=max_length, truncation=True,  padding= 'max_length', return_token_type_ids=False, return_tensors="tf")
            logits_batch = self.model(tokenized_batch) # Each tokenized sentence batch fed to the model for prediction
            logits = logits_batch.logits

            predictions = np.argmax(logits, axis=-1)

            predicted_tags = [self.ids_to_labels(x.squeeze().tolist(), lookup = {0: 'O', 2: 'B-DRUG', 1: 'B-REACTION', 3: 'I-REACTION'}) for x in predictions]
            collapsed_tokens = [self.collapse_tokens(e, max_length) for e in pred_batch]
            mapped_tags = [self.map_to_tags(collapsed_tokens[i], predicted_tags[i], logits[i]) for i in range(len(pred_batch))]
            print('mapped_tags', mapped_tags)

            for i in range(len(pred_batch)):
                try:
                    output.append(self.get_drug_reaction(pred_batch[i], mapped_tags[i]))
                except:
                    print(i)
                    print(pred_batch[i])
        print('output', output)
        return output


    def get_drug_reaction(self, text, output):
        """ Parses the Tags and input text to generate Drug and Reaction strings.

        Given the tagged outputs of the Span model, we find the corresponding Drug words and
        Reaction words in the input text, and return these as strings to the main function.

        """
        drug_found = ''
        reaction_found = ''
        text = text.split(' ')
        for i in range(len(output)):
            if output[i].endswith('DRUG'):
                if drug_found != '':
                    drug_found =  drug_found + ', '
                drug_found = drug_found + text[i]
            if output[i].endswith('REACTION'):
                if i != 0 and (output[i-1] == 'O' or output[i-1] == 'DRUG') and reaction_found != '':
                    reaction_found = reaction_found + ','
                reaction_found = reaction_found + ' '+ text[i]
        return (drug_found.strip(), reaction_found.strip())

    def predict_csv(self):
        """ Predicts Span of Drug and Reaction for all examples in the file.

        This function will load a trained NER/Span model, and pass all the rows of the 'processedText'
        column of 'csvfile.csv', preprocessed in main.py, to the model. This function will return the
        Drugs and Reactions predicted (for each input), and returns these Lists of Strings to the main function.

        Returns:
            Tuple, containing the Drugs predicted and the Reactions (both as Lists of Strings) and the
            corresponding original text inputs passed by User (also as a List of Strings).

        """

        testfilepath = "/csvfile.csv"
        testdf = pd.read_csv(testfilepath,lineterminator="\n")

        output = self.predict(testdf['processedText'].tolist())

        drug = []
        reaction = []


        for i in output:
            drug.append(i[0])
            reaction.append(i[1])

        return (
            drug,
            reaction,
            list(testdf['text']),
        )
    def predict_text(self,text):
        """ Predicts Span of Drug and Reaction for the text input.

        This function will load a trained NER/Span model, and pass the text input passed to it,
        preprocessed in main.py, to the model. This function will return the Drugs and Reactions
        predicted, and returns these strings to the main function.

        Returns:
            Tuple, containing the Drugs predicted and the Reactions (both as Strings) and the
            corresponding original text input passed by User (also as a String).

        """

        output = self.predict([text])
        return (
            output[0][0],
            output[0][1],
            text,
        )

def get_span_model():
    """ Returns the SpanModel object.

    The instantiated SpanModel object will be used in the main.py function to run the required functions for each end point.

    Returns:
      SpanModel object

    """
    model = SpanModel()
    return model
