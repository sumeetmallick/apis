import uvicorn
from fastapi import FastAPI, Depends, File, UploadFile
from fastapi import Form
import numpy as np
import pandas as pd
import tensorflow as tf
from pydantic import BaseModel
from typing import List, Optional
from fastapi.responses import HTMLResponse
import json
from fastapi.middleware.cors import CORSMiddleware
import os
import gc

from app.ner_model import SpanModel, get_span_model
from app.summ_model import SummModel, get_summ_model
from app.class_model import ClassModel, get_class_model
from app.preprocessing import PreprocessingPipeline, get_pipeline

pipeline = get_pipeline()

app = FastAPI()

origins = [
    "*"
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get('/')
def health_check():
    return "True"
@app.get('/api')
def health_check():
    return "True"
@app.get('/api/healthcheck')
def health_check():
    return "True"

@app.get("/api/predict")
async def create_file():
    return 'true'




@app.post("/api/uploadfiles")
async def create_upload_files(file: UploadFile = File(None), threshold: float = Form(0.5)):
    """ The endpoint to receive a Form Data object with File and Threshold.

    This function deals with the /uploadfiles endpoint, which receives a Form Data request object, and parses it to get
    the uploaded file (which should be a CSV with a required column 'text') and a Threshold value, which is a Float number
    between 0 and 1 (Key 'threshold'). It calls the models in turn, and returns the predictions made.

    Args:
        file: The FastAPI File object being sent as Form Data request (Optional). Default is None.
        threshold: A float value between 0 and 1, sent as Form Data request. Default is 0.5.

    Returns:
        A JSON object containing the original text inputs (Text), the Classification output (isAdverseEvent), the NER model
        outputs (predictedDrug and predictedReaction) and the Summarization model output (summary).

    """

    print('Threshold is:', threshold)
    print('File received is:', file.filename)

    if not file.filename.endswith('.csv'):
        print('Not a CSV file.')
        return {'Text':'Please send a CSV file.', 'isAdverseEvent':0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    if type(threshold) is not float or threshold<0 or threshold>1:
        print('Threshold is invalid.')
        return {'Text':'Invalid threshold', 'isAdverseEvent':0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    contents = file.file.read()

    f = open('csvfile.csv','w')
    f.write(contents.decode("utf-8"))
    f.close()

    if not os.path.getsize("csvfile.csv"):
        print('No file sent, or empty file sent. ')
        return {'Text':'No file sent, or empty file sent.', 'isAdverseEvent': 0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    contents = pd.read_csv('csvfile.csv')

    if not len(contents.index):
        print('Empty file.')
        return {'Text':'Empty file.', 'isAdverseEvent': 0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    if len(contents) > 50:
        print('Input file has ', len(contents), ' rows. Too many to process.')
        return {'Text':'Too many records to process. Please restrict to 50.', 'isAdverseEvent': 0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}
    else:
        print('Input file has ', len(contents), ' records to process.')

    try:
        x = contents['text']
        print(contents.columns)
    except:
        print("doesn't contain header as 'text'")
        try:
            x = contents['Text']
            print('x', x)
            contents.rename({'Text':'text'}, inplace=True, axis='columns')
        except:
            try:
                x = contents['TEXT']
                contents.rename({'TEXT':'text'}, inplace=True, axis='columns')
            except:
                try:
                    x = contents['txt']
                    contents.rename({'txt':'text'}, inplace=True, axis='columns')
                except:
                    print("doesn't fit any of the expected formats")
                    return {'Text':'Invalid Format for File', 'isAdverseEvent': 0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    contents = pd.DataFrame(contents['text'])
    contents['processedText'] = contents.apply(lambda row: pipeline.execute_pipeline(row["text"]), axis=1)
    contents.to_csv('csvfile.csv', index=False, header=['text', 'processedText'])


    print('Number of available GPUs: ',len(tf.config.list_physical_devices('GPU')))

    class_model = get_class_model()

    pred_label, text = class_model.predict_csv(threshold)
    del class_model
    gc.collect()

    d = {'Text': text, 'isAdverseEvent': pred_label}

    ner_model = get_span_model()
    pred_drug, pred_reaction, text = ner_model.predict_csv()
    del ner_model
    gc.collect()
    d['predictedDrug'], d['predictedReaction'] = pred_drug, pred_reaction

    summ_model = get_summ_model()
    summaries = summ_model.predict_csv()
    del summ_model
    gc.collect()
    d['summary'] = summaries

    d = pd.DataFrame.from_dict(d)
    d = d.to_dict('records')
    print('Response to UI-->', d)
    return d


@app.post("/api/postTEST")
async def post_text(text: str = Form(...)):
    print(text)
    return text


@app.post("/api/uploadtext")
async def create_upload_text(text: str = Form(None), threshold: float = Form(0.5)):
    """ The endpoint to receive a Form Data object with Input Text and Threshold.

    This function deals with the /uploadtext endpoint, which receives a Form Data request object, and parses it to get
    the input text (a single string, called with a Key 'text' ) and a Threshold value, which is a Float number
    between 0 and 1 (Key 'threshold'). It calls the models in turn, and returns the predictions made.

    Args:
        text: The input text being sent as Form Data request string. Default is "".
        threshold: A float value between 0 and 1, sent as Form Data request. Default is 0.5.

    Returns:
        A JSON object containing the original text input (Text), the Classification output (isAdverseEvent), the NER model
        outputs (predictedDrug and predictedReaction) and the Summarization model output (summary).

    """

    if len(text) < 3:
        return {'Text':text, 'isAdverseEvent': 0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    if type(threshold) is not float or threshold<0 or threshold>1:
        return {'Text':'Invalid threshold.', 'isAdverseEvent': 0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    print('Threshold:', threshold)

    original = text
    text = pipeline.execute_pipeline(text)

    if text.strip() == '' or len(text) < 3:
        return {'Text':original, 'isAdverseEvent': 0, 'predictedDrug':'', 'predictedReaction':'', 'summary':''}

    print('Number of available GPUs: ',len(tf.config.list_physical_devices('GPU')))

    class_model = get_class_model()
    pred_label, text = class_model.predict_text(text, threshold)
    del class_model
    gc.collect()

    d = {'Text': original, 'isAdverseEvent': pred_label}

    ner_model = get_span_model()
    pred_drug, pred_reaction, text = ner_model.predict_text(text)
    del ner_model
    gc.collect()

    d['predictedDrug'], d['predictedReaction'] = pred_drug, pred_reaction

    summ_model = get_summ_model()
    d['summary'] = summ_model.predict_text(text)
    del summ_model
    gc.collect()

    d = pd.DataFrame.from_dict(d)
    d = d.to_dict('records')
    print('Response to UI-->', d)
    return d

# 5. Run the API with uvicorn
#    Will run on http://127.0.0.1:8000
if __name__ == '__main__':

    uvicorn.run(app, host='0.0.0.0', port=8000)

#uvicorn app:app --reload
