weights = {
    "classification_model": "mnt/model_weights/classification/classification/roberta/best-roberta-with-slang/tf_model.h5",
    "ner_model": "mnt/model_weights/Span/e2e/Roberta_roberta-large_b-drug_1619162263",
    "summ_model": "/mnt/models/irms/t5-large-span-f",
    }
